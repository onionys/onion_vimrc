#!/usr/bin/env python
info_path = '/home/pi/info/'
system_run = True
main_loop_delay = 0.05
prog = 1
seg = 1
pre_heat_time = 10.0
time_start = 0.0
eur2404 = ""
trig_pulses_data = {}
save_path = "/home/pi/savedata/"
prog_filename = save_path + "config.txt"

# 0: prog num
# 1: seg num
# 2: seg type : 0:end 1:ramp.rate 2:ramp.time 3:dwell 4:step 5:call
# 3: if stype == 1,2,3 :target point
# 4: if stype == 1 : Rate
#    if stype == 2,3 : duration
# 
# 5: if stype == 0 : end type : 0: Reset 1:Indefinate Dwell 2:SetOutput
#    if stype == 5 : Prog num
# 
# 6: if stype == 5 : cycle num
# ----
# 7: target : ABCD
# 8: Laser Pulse target
# 9: Laser Pulse Freq
head_msg = "#prog, seg, set_type, TargetPoint, Rate or Duration, endtype or ProgNum, cycleNum, PLD_Target, Pulse_Target, Pulse_Freq\n"

def save_prog_file(data,filename):
    with open(filename,'w') as inf:
        inf.write(head_msg)
        for seg in data:
            msg = ",".join([str(i) for i in seg])
            inf.write(msg + '\n')

def load_prog_file(filename):
    data = []
    with open(filename) as inf:
        head = inf.readline()
        for line in inf:
            data.append([int(i) for i in line.split(',')])
    return data

if __name__=="__main__":
    data = load_prog_file('test')
    print data
    for i in range(len(data)):
        for j in range(len(data[i])):
            data[i][j] += 1
    save_prog_file(data,'test2')
