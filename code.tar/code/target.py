
from RPi import GPIO
import config
from motor import motor

class motor:
    def __init__(self,gpio_pin=22, level_inverse=False):
        self.pin = gpio_pin
        self.lv_inverse = level_inverse
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup( gpio_pin, GPIO.OUT)
        GPIO.output(self.pin, 1 if self.lv_inverse else 0)

    def on(self):
        GPIO.output(self.pin, 0 if self.lv_inverse else 1)

    def off(self):
        GPIO.output(self.pin, 1 if self.lv_inverse else 0)

    def get_lv(self):
        return GPIO.input(self.pin)


class target:
    def __init__(self,target,pin_A ,pin_B, pin_C, pin_D):
        self.A = pin_A
        self.B = pin_B
        self.C = pin_C
        self.D = pin_D
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.A, GPIO.IN)
        GPIO.setup(self.B, GPIO.IN)
        GPIO.setup(self.C, GPIO.IN)
        GPIO.setup(self.D, GPIO.IN)
