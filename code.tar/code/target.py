#!/usr/bin/env python
from threading import Thread
from RPi import GPIO
import config
from time import sleep

class motor:
    def __init__(self,gpio_pin=22, level_inverse=False):
        self.pin = gpio_pin
        self.lv_inverse = level_inverse
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup( gpio_pin, GPIO.OUT)
        GPIO.output(self.pin, 1 if self.lv_inverse else 0)

    def on(self):
        GPIO.output(self.pin, 0 if self.lv_inverse else 1)

    def off(self):
        GPIO.output(self.pin, 1 if self.lv_inverse else 0)

    def get_lv(self):
        return GPIO.input(self.pin)


class pld_target:
    def __init__(self,target,pin_A=40,pin_B=38, pin_C=36, pin_D=32, lv_inverse = True):
        self.motor = motor()
        self.pin_A = pin_A
        self.pin_B = pin_B
        self.pin_C = pin_C
        self.pin_D = pin_D
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.pin_A, GPIO.IN)
        GPIO.setup(self.pin_B, GPIO.IN)
        GPIO.setup(self.pin_C, GPIO.IN)
        GPIO.setup(self.pin_D, GPIO.IN)
        self.buff = {}
        self.target ='A'
        self.set_target(target)
        GPIO.add_event_detect(self.pin_A, GPIO.BOTH ,callback=self.interrupt_hand)
        GPIO.add_event_detect(self.pin_B, GPIO.BOTH ,callback=self.interrupt_hand)
        GPIO.add_event_detect(self.pin_C, GPIO.BOTH ,callback=self.interrupt_hand)
        GPIO.add_event_detect(self.pin_D, GPIO.BOTH ,callback=self.interrupt_hand)
        self.lv_inverse = lv_inverse

    def read_all(self):
        if(self.lv_inverse):
            self.buff['A'] = 0 if GPIO.input(self.pin_A) else 1 
            self.buff['B'] = 0 if GPIO.input(self.pin_B) else 1
            self.buff['C'] = 0 if GPIO.input(self.pin_C) else 1
            self.buff['D'] = 0 if GPIO.input(self.pin_D) else 1
        else:
            self.buff['A'] = 1 if GPIO.input(self.pin_A) else 0 
            self.buff['B'] = 1 if GPIO.input(self.pin_B) else 0
            self.buff['C'] = 1 if GPIO.input(self.pin_C) else 0
            self.buff['D'] = 1 if GPIO.input(self.pin_D) else 0
        print self.buff

    def switch_by_situation(self):
        if((self.buff['A']==1) and (self.buff['B']==0) and (self.buff['C']==0) and(self.buff['D']==0)):
            if(self.target == 'A'):
                self.motor.off()
            else:
                self.motor.on()
        elif((self.buff['A']==0) and (self.buff['B']==1) and (self.buff['C']==0) and(self.buff['D']==0)):
            if(self.target == 'B'):
                self.motor.off()
            else:
                self.motor.on()
        elif((self.buff['A']==0) and (self.buff['B']==0) and (self.buff['C']==1) and(self.buff['D']==0)):
            if(self.target == 'C'):
                self.motor.off()
            else:
                self.motor.on()
        elif((self.buff['A']==0) and (self.buff['B']==0) and (self.buff['C']==0) and(self.buff['D']==1)):
            if(self.target == 'D'):
                self.motor.off()
            else:
                self.motor.on()
        elif((self.buff['A']==0) and (self.buff['B']==0) and (self.buff['C']==0) and(self.buff['D']==0)):
            self.motor.on()
        else:
            self.motor.off()
            self.error = 1

    def run(self):
        self.thread = Thread(target=self.thread_func,args=())
        self.thread.start()

    def thread_func(self):
        while(config.system_run):
            sleep(1)
            self.read_all()
            self.switch_by_situation()
        GPIO.remove_event_detect(self.pin_A)
        GPIO.remove_event_detect(self.pin_B)
        GPIO.remove_event_detect(self.pin_C)
        GPIO.remove_event_detect(self.pin_D)

    def interrupt_hand(self,ch):
        self.read_all()
        self.switch_by_situation()
    
    def set_target(self, target):
        if(target in list('ABCD')):
            self.target = target

if __name__=="__main__":
    targ = pld_target('A')
    targ.run()
    for i in range(30):
        targ.set_target('A')
        sleep(1)
        targ.set_target('B')
        sleep(1)
        targ.set_target('C')
        sleep(1)
        targ.set_target('D')
        sleep(1)
    config.system_run = False
    targ.motor.off()

