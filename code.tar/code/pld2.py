#!/usr/bin/env python
#-*-coding:utf-8-*-

import os
from RPi import GPIO
from time import sleep, time
from threading import Thread

import config
from target import target
from krfLaser import krfLaser
from sys_mon import sys_monintor

GPIO.setmode(GPIO.BOARD)
info_path = '/home/pi/info/'






if __name__ == "__main__":
    GPIO.setmode(GPIO.BOARD)
    print "test"
    GPIO.cleanup()

