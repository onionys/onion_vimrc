#!/usr/bin/env python
#-*-coding:utf-8-*-

import os
from RPi import GPIO
from time import sleep, time
from threading import Thread

import config
from target import pld_target
from krfLaser import krfLaser
from sys_mon import sys_monintor




class pld_system:
    def __init__(self):

        self.operations = {
                1 : oper_reset
                2 : oper_run,
                4 : oper_hold,
                8 : oper_holdback,
                16: oper_complete,
                }
        self.krf = krfLaser()
        self.target = pld_target('A')
        self.mon = sys_monintor(config.krf, config.target)
        self.eur = eur2404()
        self.prog = self.eur.get_prog()
        self.seg  = self.eur.get_seg()
        self.time_start = time()
        self.pre_heat_time = 10.*60.

        self.krf.run()
        self.target.run()
        self.mon.run()

    def reset(self):
        print ""

    ## operation run
    def run(self):
    
        #check the prog seg is changed?
        _prog = config.eur.get_prog()
        _seg  = config.eur.get_seg()
        if((self.prog != _prog) or (self.seg != _seg)):
            self.prog = prog
            self.seg  = seg
            self.time_start = time()
            # laser stop,reset,load data by prog, seg
            # target load data by prog, seg
    
        # hold for pre heat
        if( ( time() < ( self.pre_heat_time + self.time_start ) ) ):
            # laser off
            return

        # target check
        if(self.target.get_position() != self.target.get_target()):
            # laser off
            self.krf.set_laser_off()
            return

        # laser check
        if(self.krf.target_pulses < self.krf.recv_pulses): # seg complete 
            # laser off
            self.krf.set_laser_off()
            # eur skip
            return

        if(config.krf.get_miss_pulses() >= config.krf.max_miss_pulses):
            # laser off
            self.krf.set_laser_off()
            # eur reset 
            self.eur.reset()
            # announced miss-too-much error
            return
    
        config.krf.set_laser_on()
    
        if(config.krf.target_pulses < config.krf.recv_pulses):
            if(config.krf.get_miss_pulses() >= config.krf.max_miss_pulses):
                config.krf.set_laser_off()
                #config.eur2404.set_operation("standby")
            return


    def hold(self):
        ## krf laser hold 
        ## target do nothing
        ##
        print ""

    def holdback(self):

        print ""

    def complete(self):
        ## krf laser reset
        print ''




if __name__ == "__main__":

    GPIO.setmode(GPIO.BOARD)

    krf = krfLaser()
    krf.run()
    config.krf = krf

    target = pld_target('A')
    target.run()
    config.target = target

    mon = sys_monintor(krf, target)
    mon.run()
    config.mon = mon
    
    config.time_start = time()
    while(config.system_run):
        config.stat = config.eur2404.get_stat()
        operations.get(config.stat)()

        sleep(config.main_loop_delay)

    GPIO.cleanup()
