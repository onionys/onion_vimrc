#!/usr/bin/env python
#-*-coding:utf-8-*-
import minimalmodbus
from time import sleep


class eur2404:
    def __init__(self, addr ):
        self.addr = addr
        self.bus = minimalmodbus.Instrument('/dev/ttyUSB0',self.addr)
        self.bus.serial.baudrate = 9600
        self.bus.serial.bytesize = 8 
        self.bus.serial.parity = minimalmodbus.serial.PARITY_NONE
        self.bus.serial.stopbits = 1
        self.bus.serial.timeout = 0.05
        self.bus.serial.mode = minimalmodbus.MODE_RTU

    ## -- GET --
    ### -- HOME TAB --
    def get_PV(self):
        addr = 1
        return self.bus.read_register(addr,0)

    def get_SP(self):
        addr = 2
        return self.bus.read_register(addr,0)

    def get_OP(self):
        addr = 3
        return self.bus.read_register(addr,0)

    def get_working_SP():
        addr = 5
        return self.bus.read_register(addr,0)

    def get_auto_manu_select():
        addr = 273
        return self.bus.read_register(addr,0)

    ## -- Run Tab --

    def get_prog(self):
        addr = 22
        return self.bus.read_register(addr,0)

    def get_stat(self): # 1:Reset 2:Run 4:hold 8:holdback 16:complete
        addr = 23
        return self.bus.read_register(addr,0)

    def get_prog_target_point(self):
        addr = 163
        return self.bus.read_register(addr,0)

    def get_prog_cycles_remins(self):
        addr = 59 
        return self.bus.read_register(addr,0)

    def get_current_seg(self):
        addr = 56
        return self.bus.read_register(addr,0)

    def get_current_seg_type(self):
        addr = 29
        return self.bus.read_register(addr,0)

    def get_seg_time_remain_sec(self):
        addr = 36
        return self.bus.read_register(addr,0)

    def get_seg_time_remain_min(self):
        addr = 63
        return self.bus.read_register(addr,0)

    def get_current_seg_target_setpoint(self):
        addr = 160
        return self.bus.read_register(addr,0)

    def get_ramp_rate(self):
        addr = 161
        return self.bus.read_register(addr,0)

    def get_prog_time_remain(self):
        addr = 58
        return self.bus.read_register(addr,0)

    def get_fast_run(self):
        addr = 57
        return self.bus.read_register(addr,0)

    def get_skip_seg_flag(self):
        addr = 154
        return self.bus.read_register(addr,0)

    def get_0_seg_type(self, prog, seg):
        base_addr = 8192 + prog * 136 + seg * 8 
        return self.bus.read_register(base_addr,0)

    def get_1_target_point(self, prog, seg):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_0_seg_type(prog,seg) in [1,2,4]):
            _addr = base_addr + 1
            return self.bus.read_register(_addr,0)
        else:
            return None

    def get_2_rate(self, prog,seg):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_0_seg_type(prog,seg) == 1):
            _addr = base_addr + 2
            return self.bus.read_register(_addr,0)
        else:
            return None

    def get_2_duration(self, prog, seg):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_0_seg_type(prog,seg) in [2,3]):
            _addr = base_addr + 2
            return self.bus.read_register(_addr,0)
        else:
            return None

    def get_3_endtype(self, prog, seg):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_0_seg_type(prog,seg) == 0):
            _addr = base_addr + 3
            return self.bus.read_register(_addr,0)
        else:
            return None

    def get_3_prog_num(self, prog, seg):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_0_seg_type(prog,seg) == 5):
            _addr = base_addr + 3
            return self.bus.read_register(_addr,0)
        else:
            return None

    def get_4_cycle(self, prog, seg):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_0_seg_type(prog,seg) == 5):
            _addr = base_addr + 4
            return self.bus.read_register(_addr,0)
        else:
            return None

    def get_fast_status_byte(self):
        addr = 74
        return self.bus.read_register(addr,0)

    def get_ctrl_status_word(self):
        addr = 77
        return self.bus.read_register(addr,0)

    def get_prog_logic_status(self):
        addr = 162
        return self.bus.read_register(addr,0)

    def get_digital_output_status_word(self):
        addr = 551
        return self.bus.read_register(addr,0)

    def get_digital_input_status_word(self):
        addr = 87
        return self.bus.read_register(addr,0)

    ## -- SET --

    def set_SP(self,val):
        addr = 2
        if(val >=0):
            self.bus.write_register(addr,int(val))

    def set_OP(self,val):
        addr = 3
        if(val >=0):
            self.bus.write_register(addr,int(val))

    def set_prog(self,val):
        addr = 22
        self.bus.write_register(addr,int(val))

    def set_seg(self,val):
        addr = 56
        self.bus.write_register(addr,int(val))

    def set_stat(self,stat):
        if mode in [1,2,4,8,16]:
            addr = 23
            self.bus.write_register(addr,int(val))

    def set_prog_target_point(self,val):
        addr = 163
        self.bus.write_register(addr,int(val))

    def set_cycles_remins(self,val):
        addr = 59 
        self.bus.write_register(addr,int(val))

    def set_seg_type(self,val):
        addr = 29
        self.bus.write_register(addr,int(val))
        
    def set_seg_time_remain_sec(self,val):
        addr = 36
        self.bus.write_register(addr,int(val))

    def set_seg_time_remain_min(self,val):
        addr = 63
        self.bus.write_register(addr,int(val))

    def set_cycles_remins(self,val):
        addr = 59 
        self.bus.write_register(addr,int(val))

    def set_0_seg_type(self, prog, seg, val):
        base_addr = 8192 + prog * 136 + seg * 8 
        if(not val in [0,1,2,3,4,5]):
            # log error message
            return None
        self.bus.write_register(base_addr,int(val))

    def set_1_target_point(self, prog, seg, val):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_seg_type(prog,seg) in [1,2,4]):
            addr = base_addr + 1
            self.bus.write_register(addr,int(val))
        else:
            return None

    def set_2_rate(self, prog,seg, val):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_seg_type(prog,seg) == 1):
            addr = base_addr + 2
            self.bus.write_register(addr,int(val))
            return ""
        else:
            return None

    def set_2_duration(self, prog, seg, val):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_seg_type(prog,seg) in [2,3]):
            addr = base_addr + 2
            self.bus.write_register(addr,int(val))
            return ""
        else:
            return None

    def set_3_endtype(self, prog, seg, val):
        base_addr = 8192 + prog * 136 + seg * 8
        if(not val in [0,1,2]):
            # log error message
            return None
        if(self.get_seg_type(prog,seg) == 0):
            addr = base_addr + 3
            self.bus.write_register(addr,int(val))
            return ""
        else:
            return None

    def set_3_prog_num(self, prog, seg, val):
        base_addr = 8192 + prog * 136 + seg * 8
        if(not val in range(1,20+1)):
            # log error message
            return None
        if(self.get_seg_type(prog,seg) == 5):
            addr = base_addr + 3
            self.bus.write_register(addr,int(val))
            return ""
        else:
            return None

    def set_4_cycle(self, prog, seg, val):
        base_addr = 8192 + prog * 136 + seg * 8
        if(self.get_seg_type(prog,seg) == 5):
            addr = base_addr + 4
            self.bus.write_register(addr,int(val))
        else:
            return None

    def skip_seg_flag(self):
        addr = 154
        val = 1
        self.bus.write_register(addr,int(val))

    def set_auto(self):
        addr = 273
        val = 0
        self.bus.write_register(addr,int(val))

    def set_manual(self):
        addr = 273
        val = 1
        self.bus.write_register(addr,int(val))

    ## -- OTHER COMMAND --
    def reset(self):
        self.set_stat(1)

    def run(self):
        self.set_stat(2)

    def hold(self):
        self.set_stat(4)

    def holdback(self):
        self.set_stat(8)

    def complete(self):
        self.set_stat(16)

    def skip(self):
        addr = 154
        self.bus.write_register(addr,1)

    def get_all_prog(self):
        for p in range(1,20+1):
            for s in range(1,16+1):
                data = [None, None, None, None, None]
                data[0] = self.get_0_seg_type(p,s)
                if(data[0]== 0):
                    data[3] = self.get_3_endtype(p,s)
                if(data[0] == 1):
                    data[1] = self.get_1_target_point(p,s)
                    data[2] = self.get_2_rate(p,s)
                if(data[0]== 2):
                    data[1] = self.get_1_target_point(p,s)
                    data[2] = self.get_2_duration(p,s)
                if(data[0]== 3):
                    data[2] = self.get_2_duration(p,s)
                if(data[0]== 4):
                    data[1] = self.get_1_target_point(p,s)
                if(data[0]== 5):
                    data[3] = self.get_1_target_point(p,s)
                    data[4] = self.get_4_cycle(p,s)
                data = [p,s] + data
                yield data


def test_show_all_prog_seg(eur):
    for p in range(1,20+1):
        for s in range(1,16+1):
            typ = eur.get_0_seg_type(p,s)
            tp = eur.get_1_target_point(p,s)
            print "p:%2d s:%2d : type %2d target: %2d" % (p,s,typ if type else 0, tp if tp else 0)


if __name__ == "__main__":
    eur = eur2404(1)
    print "START"
    for i in eur.get_all_prog():
        print i
