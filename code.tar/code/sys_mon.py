#!/usr/bin/env python
#-*-coding:utf-8-*-
import config
import os
from time import sleep
from threading import Thread
from krfLaser import krfLaser
from target import pld_target

class sys_monintor:
    def __init__(self,  krf, target):
        self.krf = krf
        self.target = target

        self.target_path = config.info_path + "target/"
        self.make_info_path(self.target_path)

        self.krf_path = config.info_path + "krf/"
        self.make_info_path(self.krf_path)
        self.delay = 1
        self.file_sets = set([])

    def make_info_path(self, path):
        if(not os.path.exists(path)):
            os.mkdir(path)

    def set_time_delay(self,delay):
        if(delay>0.0):
            self.delay = delay

    def write_krf_info(self,filename,msg):
        filename = self.krf_path + filename
        self.file_sets.add(filename)
        with open(filename,"w") as ofile:
            ofile.write(msg + '\n')
        os.chmod(filename,0755)

    def write_target_info(self, filename, msg):
        filename = self.target_path + filename
        self.file_sets.add(filename)
        with open(filename,"w") as ofile:
            ofile.write(msg + '\n')
        os.chmod(filename,0755)

    def krf_info(self):
        self.write_krf_info("freq_hz"        , str(self.krf.get_freq()))
        self.write_krf_info("target_pulses"  , str(self.krf.target_pulses))
        self.write_krf_info("recv_pulses"    , str(self.krf.recv_pulses))
        self.write_krf_info("trig_pulses"    , str(self.krf.trig_pulses))
        self.write_krf_info("max_miss_pulses", str(self.krf.max_miss_pulses))
        self.write_krf_info("trigg_pin"      , str(self.krf.pin_out))
        self.write_krf_info("recv_pin"       , str(self.krf.pin_in))
        self.write_krf_info("laser_on_off"   , "1" if self.krf.laser_on else "0")
        self.write_krf_info("out_inverse"    , "1" if self.krf.out_inverse else "0")

    def target_info(self):
        self.write_target_info("pin_A"    , str(self.target.pin_A ))
        self.write_target_info("pin_B"    , str(self.target.pin_B ))
        self.write_target_info("pin_C"    , str(self.target.pin_C ))
        self.write_target_info("pin_D"    , str(self.target.pin_D ))
        sensors_lv = "A:%d B:%d C:%d D:%d" % (self.target.buff["A"],self.target.buff["B"],self.target.buff["C"],self.target.buff["D"])
        self.write_target_info("sensors_lv" , sensors_lv)
        self.write_target_info("motor_on_off" , str(self.target.motor.is_motor_on()))
        self.write_target_info("motor_pin" , str(self.target.motor.pin))
        self.write_target_info("position" , self.target.position)

    def thread_func(self):
        while(config.system_run):
            self.krf_info()
            self.target_info()
            sleep(self.delay)

    def run(self):
        self.thread = Thread(target=self.thread_func, args=())
        self.thread.start()

    def show(self):
        print "-----------------------------------"
        for i in self.file_sets:
            with open(i) as f:
                print "%20s:\t%s" % (i[13:],f.read().strip())


if __name__ == "__main__":
    targ = pld_target('A')
    krf = krfLaser()
    targ.run()
    krf.run()
    mon = sys_monintor(krf,targ)
    mon.run()
    for i in range(10):
        mon.show()
        sleep(1)
    config.system_run = False
