
import config
import os

class sys_monintor:
    def __init__(self,motor,krf):
        self.motor = motor
        self.krf = krf
        self.motor_path = info_path + "motor/"
        self.krf_path = info_path + "krf/"
        if(not os.path.exists(self.krf_path)):
            os.mkdir(self.krf_path )
        if(not os.path.exists(self.motor_path)):
            os.mkdir(self.motor_path )
        self.delay = 1

    def krf_info(self):
        filename = self.krf_path + "all_info"
        with open(filename,"w",) as outf:
            outf.write( "\npin_in: %d \t pin_out : %d" % (self.krf.pin_in, self.krf.pin_out) )
            outf.write( "\ntarget: %d \t trig: %d \t recv: %d" % (self.krf.target_pulses, self.krf.trig_pulses, self.krf.recv_pulses) )
            outf.write( "\nmax_miss: %d \t miss: %d\n" % (self.krf.max_miss_pulses, self.krf.trig_pulses - self.krf.recv_pulses) )
            outf.write( "\nLaser : %s" % "ON" if self.krf.laser_on else "OFF" )
            outf.write( "\nfreq : %f" % (1.0 / self.krf.pulse_width) )
        os.chmod(filename,0777)

    def thread_func(self):
        while(config.system_run):
            self.krf_info()
            sleep(1)
