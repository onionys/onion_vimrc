#!/usr/bin/env python

from threading import Thread
from time import sleep
from time import time
import random
import matplotlib.pyplot as plt
import matplotlib.animation as animation


fig = plt.figure()
ax1 = fig.add_subplot(111)

xlist = [time()]
ylist = [random.randint(1,100)]


def animate_(i):
    ax1.plot(xlist,ylist)

ani = animation.FuncAnimation(fig, animate_, interval = 1000)

def add_plot():
    for i in range(100):
        sleep(0.5)
        xlist.append(time())
        ylist.append(random.randint(1,100))

th = Thread(target = add_plot, args=())
th.start()

plt.show()
