#!/usr/bin/env python

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import matplotlib.animation as animation

from threading import Thread
from time import sleep, time
import random
import os 
import Tkinter
import config

class main_gui:
    def __init__(self):
        self.xdata = []
        self.ydata = []
        self.labels = []
        self.buttons = []
        self.fig = Figure(figsize=(5,4), dpi= 100)
        self.ax = self.fig.add_subplot(111)
        self.ax.plot(self.xdata,self.ydata)

        self.root = Tkinter.Tk()
        self.button_frame = Tkinter.Frame(self.root)
        self.button_frame.grid(row=0,column=0)
        self.buttons.append(create_button(button_frame,"reset"    ,0,0,  pld_cmd.reset     ))
        self.buttons.append(create_button(button_frame,"run"      ,1,0,  pld_cmd.run       ))
        self.buttons.append(create_button(button_frame,"hold"     ,2,0,  pld_cmd.hold      ))
        self.buttons.append(create_button(button_frame,"holdback" ,3,0,  pld_cmd.holdback  ))
        self.buttons.append(create_button(button_frame,"complete" ,4,0,  pld_cmd.complete  ))
        self.buttons.append(create_button(button_frame,"laser on" ,0,2,  pld_cmd.laser_on  ))
        self.buttons.append(create_button(button_frame,"laser off",1,2,  pld_cmd.laser_off ))
        self.buttons.append(create_button(button_frame,"target A",0,3,   pld_cmd.target_A  ))
        self.buttons.append(create_button(button_frame,"target B",1,3,   pld_cmd.target_B  ))
        self.buttons.append(create_button(button_frame,"target C",2,3,   pld_cmd.target_C  ))
        self.buttons.append(create_button(button_frame,"target D",3,3,   pld_cmd.target_D  ))
        self.buttons.append(create_button(button_frame,"system off",5,5, pld_cmd.system_off))

        self.label_frame = Tkinter.Frame(root)
        self.label_frame.grid(row=0,column=1)
        self.labels.append(create_label(label_frame,"AAA",0,1))
        self.labels.append(create_label(label_frame,"BBB",1,1))
        self.labels.append(create_label(label_frame,"CCC",2,1))
        self.labels.append(create_label(label_frame,"DDD",3,1))
        self.labels.append(create_label(label_frame,"EEE",4,1))

        ### make and add a matplot plot ####
        self.plot_frame = Tkinter.Frame(root)
        self.plot_frame.grid(row = 1, column = 0)
        self.canvas = FigureCanvasTkAgg(fig, master = plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack()
        self.ani = animation.FuncAnimation(self.fig, self.animate_, interval=1000)
        #self.root.mainloop()


    def create_button(self,par,txt,ro,co,cmd):
        button = Tkinter.Button(par,text=txt)
        button.grid(row=ro, column=co)
        button["command"] = cmd
        button['width'] = 8
        button['height'] = 2
        return button

    def create_label(self,par,txt,ro,co):
        label = Tkinter.Label(par,text=txt)
        label.grid(row=ro, column=co)
        label['width'] = 8
        label['height'] = 2
        return label

    def animate_(self,i):
        self.xdata.append(time())
        self.ydata.append(random.randint(1,100))
        self.ax.plot(self.xdata, self.ydata)

    def cmd_reset(self):
        print ""

    def cmd_run(self):
        print ""

    def cmd_hold(self):
        print ""

    def cmd_holdback(self):
        print ""

    def cmd_complete(self):
        print ""

    def cmd_laser_on(self):
        print ""

    def cmd_laser_off(self):
        print ""

    def cmd_target_A(self):
        print ""

    def cmd_target_B(self):
        print ""

    def cmd_target_C(self):
        print ""

    def cmd_target_D(self):
        print ""

    def cmd_system_off(self):
        print ""




if __name__ == "__main__":
    gui = main_gui()
    gui.root.mainloop()
    

