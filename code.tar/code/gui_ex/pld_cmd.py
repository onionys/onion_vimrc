#!/usr/bin/env python


stat_file = "/home/pi/info/eur2404/stat"
cmd_stat_file = "/home/pi/info/cmd_stat"
cmd_sys_off = "/home/pi/info/cmd_system_off"
cmd_laser_on = "/home/pi/info/cmd_laser_on"
cmd_target_pos = "/home/pi/info/cmd_target_pos"
system_run = True

def reset():
    with open(cmd_stat_file ,'w') as wf:
        wf.write("1")

def run():
    with open(cmd_stat_file,'w') as wf:
        wf.write("2")

def hold():
    with open(cmd_stat_file,'w') as wf:
        wf.write("4")

def holdback():
    with open(cmd_stat_file,'w') as wf:
        wf.write("8")

def complete():
    with open(cmd_stat_file,'w') as wf:
        wf.write("16")

def laser_on():
    with open(cmd_laser_on,'w') as wf:
        wf.write("1")

def laser_off():
    with open(cmd_laser_on,'w') as wf:
        wf.write("0")

def system_off():
    with open(cmd_sys_off,'w') as wf:
        wf.write("1")

def target_A():
    with open(cmd_target_pos,'w') as wf:
        wf.write("A")

def target_B():
    with open(cmd_target_pos,'w') as wf:
        wf.write("B")

def target_C():
    with open(cmd_target_pos,'w') as wf:
        wf.write("C")

def target_D():
    with open(cmd_target_pos,'w') as wf:
        wf.write("D")

