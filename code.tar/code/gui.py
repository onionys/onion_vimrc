#!/usr/bin/env python

import Tkinter
from Tkinter import N,S,E,W
from time import time
import random


from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import matplotlib.animation as animation


def TODO():
    print "TODO"



class main_view:

    def __init__(self):
        self.root = Tkinter.Tk()

        # Laser Control Panel
        self.spaceline0 = Tkinter.Label(master=self.root, text="--" * 10 + "KrF Laser Control" + "--" * 10,font=("Helvetica",12))
        self.spaceline0.grid(row=0,column=0,columnspan=5,sticky=N+S+E+W)

        self.ctrl_laser_target_pulse_label = Tkinter.Label(master=self.root, text="TARGET PULSE",font=("Helvetica",12))
        self.ctrl_laser_target_pulse_entry = Tkinter.Entry(master=self.root ,font=("Helvetica",12))
        self.ctrl_laser_max_miss_pulse_label = Tkinter.Label(master=self.root, text="MAX MISS",font=("Helvetica",12))
        self.ctrl_laser_max_miss_pulse_entry = Tkinter.Entry(master=self.root ,font=("Helvetica",12))
        self.ctrl_laser_run_btn   = Tkinter.Button(master=self.root,text="RUN"  ,width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_laser_stop_btn  = Tkinter.Button(master=self.root,text="STOP" ,width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_laser_hold_btn  = Tkinter.Button(master=self.root,text="HOLD" ,width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_laser_reset_btn = Tkinter.Button(master=self.root,text="RESET",width=8,height=3,command=TODO,font=("Helvetica",12))

        self.ctrl_laser_target_pulse_label.grid(  row=1,column=0,columnspan = 2)
        self.ctrl_laser_target_pulse_entry.grid(  row=1,column=2,columnspan = 3,sticky=N+S+E+W)
        self.ctrl_laser_max_miss_pulse_label.grid(row=2,column=0,columnspan = 2)
        self.ctrl_laser_max_miss_pulse_entry.grid(  row=2,column=2,columnspan = 3,sticky=N+S+E+W)
        self.ctrl_laser_run_btn.grid(row=3,column=0,sticky=N+S+E+W)
        self.ctrl_laser_stop_btn.grid(row=3,column=1,sticky=N+S+E+W)
        self.ctrl_laser_hold_btn.grid(row=3,column=2,sticky=N+S+E+W)
        self.ctrl_laser_reset_btn.grid(row=3,column=3,sticky=N+S+E+W)

        self.ctrl_laser_target_pulse_entry.bind("<Return>",self.ctrl_laser_target_pulse_entry_enter)
        self.ctrl_laser_max_miss_pulse_entry.bind("<Return>",self.ctrl_laser_max_miss_pulse_entry_enter)

        # Eur2404 Control Panel
        self.spaceline1 = Tkinter.Label(master=self.root, text="--" * 10 + "EUR2040 Control" + "--" * 10,font=("Helvetica",12))
        self.spaceline1.grid(row=4,column=0,columnspan=5,sticky=N+S+E+W)

        self.ctrl_eur_SP_label = Tkinter.Label(master=self.root, text="SP",font=("Helvetica",12))
        self.ctrl_eur_SP_entry = Tkinter.Entry(master=self.root ,font=("Helvetica",12))
        self.ctrl_eur_OP_label = Tkinter.Label(master=self.root, text="OP",font=("Helvetica",12))
        self.ctrl_eur_OP_entry = Tkinter.Entry(master=self.root ,font=("Helvetica",12))
        self.ctrl_eur_reset_btn    = Tkinter.Button(master=self.root,text="RESET"   ,width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_eur_run_btn      = Tkinter.Button(master=self.root,text="RUN"     ,width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_eur_hold_btn     = Tkinter.Button(master=self.root,text="HOLD"    ,width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_eur_holdback_btn = Tkinter.Button(master=self.root,text="HOLDBACK",width=8,height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_eur_complete_btn = Tkinter.Button(master=self.root,text="COMPLETE",width=8,height=3,command=TODO,font=("Helvetica",12))

        self.ctrl_eur_SP_label.grid(    row=5,column=0,columnspan = 2)
        self.ctrl_eur_SP_entry.grid(    row=5,column=2,columnspan = 3,sticky=N+S+E+W)
        self.ctrl_eur_OP_label.grid(    row=6,column=0,columnspan = 2)
        self.ctrl_eur_OP_entry.grid(    row=6,column=2,columnspan = 3,sticky=N+S+E+W)
        self.ctrl_eur_reset_btn.grid(   row=7,column=0,sticky=N+S+E+W)
        self.ctrl_eur_run_btn.grid(     row=7,column=1,sticky=N+S+E+W)
        self.ctrl_eur_hold_btn.grid(    row=7,column=2,sticky=N+S+E+W)
        self.ctrl_eur_holdback_btn.grid(row=7,column=3,sticky=N+S+E+W)
        self.ctrl_eur_complete_btn.grid(row=7,column=4,sticky=N+S+E+W)

        self.ctrl_eur_SP_entry.bind("<Return>",self.ctrl_eur_SP_entry_enter)
        self.ctrl_eur_OP_entry.bind("<Return>",self.ctrl_eur_OP_entry_enter)

        # Target Control Panel
        self.spaceline2 = Tkinter.Label(master=self.root, text="--" * 10 + "TARGET Control" + "--" * 10,font=("Helvetica",12))
        self.spaceline2.grid(row=8,column=0,columnspan=5,sticky=N+S+E+W)

        self.ctrl_target_A_btn = Tkinter.Button(master=self.root,text="A",height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_target_B_btn = Tkinter.Button(master=self.root,text="B",height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_target_C_btn = Tkinter.Button(master=self.root,text="C",height=3,command=TODO,font=("Helvetica",12))
        self.ctrl_target_D_btn = Tkinter.Button(master=self.root,text="D",height=3,command=TODO,font=("Helvetica",12))

        self.ctrl_target_A_btn.grid(row=9,column=0,columnspan=2,rowspan=2,sticky=N+S+E+W)
        self.ctrl_target_B_btn.grid(row=9,column=2,columnspan=2,rowspan=2,sticky=N+S+E+W)
        self.ctrl_target_C_btn.grid(row=11,column=0,columnspan=2,rowspan=2,sticky=N+S+E+W)
        self.ctrl_target_D_btn.grid(row=11,column=2,columnspan=2,rowspan=2,sticky=N+S+E+W)

        # Laser Condition Panel
        self.cond_laser_target_pulse_var = Tkinter.StringVar()
        self.cond_laser_target_pulse_label = Tkinter.Label(master=self.root, textvariable=self.cond_laser_target_pulse_var,width=15,font=("Helvetica",12))
        self.cond_laser_target_pulse_var.set("0")
        self.cond_laser_miss_pulse_var = Tkinter.StringVar()
        self.cond_laser_miss_pulse_label = Tkinter.Label(master=self.root, textvariable=self.cond_laser_target_pulse_var,width=15,font=("Helvetica",12))
        self.cond_laser_miss_pulse_var.set("0")

        self.cond_laser_target_pulse_label.grid(row=1,column=5)
        self.cond_laser_miss_pulse_label.grid(row=2,column=5)

        # matplotlib plot 
        self.xdata = []
        self.ydata = []
        self.fig = Figure(figsize=(6,6), dpi= 100)
        self.ax = self.fig.add_subplot(111)
        self.ax.plot(self.xdata,self.ydata)
        self.canvas = FigureCanvasTkAgg(self.fig, master = self.root)
        self.canvas.draw()
        self.canvas.get_tk_widget().grid(row=1,column=6,rowspan=12,sticky=N+S+E+W)
        self.ani = animation.FuncAnimation(self.fig, self.watch_cond_func, interval=30*1000)

    def watch_cond_func(self,i):
        self.xdata.append(time())
        self.ydata.append(random.randint(1,100))
        self.ax.plot(self.xdata, self.ydata)

    def ctrl_laser_target_pulse_entry_enter(self,event):
        _entry = self.ctrl_laser_target_pulse_entry
        print _entry.get()
        _entry.delete(0,'end')

    def ctrl_laser_max_miss_pulse_entry_enter(self,event):
        _entry = self.ctrl_laser_max_miss_pulse_entry
        print _entry.get()
        _entry.delete(0,'end')

    def ctrl_eur_SP_entry_enter(self,event):
        _entry = self.ctrl_eur_SP_entry
        print _entry.get()
        _entry.delete(0,'end')

    def ctrl_eur_OP_entry_enter(self,event):
        _entry = self.ctrl_eur_OP_entry
        print _entry.get()
        _entry.delete(0,'end')

if __name__ == "__main__":
    pld_view = main_view()
    pld_view.root.mainloop()
