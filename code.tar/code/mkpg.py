#!/usr/bin/env python

data = []
for p in range(1,20+1):
    for s in range(1,16+1):
        mm = []
        mm.append(p)  ## prog
        mm.append(s)  ## seg
        mm.append(10) ## target pulse
        mm.append(1)  ## freq
        mm.append('A')## target position
        data.append(','.join([str(i) for i in mm]))

for i in data:
    print i 
