#!/usr/bin/env python

from RPi import GPIO
from time import sleep, time
from threading import Thread
import config

class krfLaser:

    def __init__(self,pin_out=16,pin_in=18,out_inverse = True):
        self.pin_out = pin_out
        self.pin_in = pin_in
        self.target_pulses = 0
        self.max_miss_pulses = 100
        self.laser_on = False
        self.pulse_delay = 1.0 / 5.0 # as pulse freq = 5 Hz

        self.recv_pulses = 0
        self.trig_pulses = 0

        self.pulse_width = 0.000010

        self.out_inverse = out_inverse

        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.pin_out, GPIO.OUT)
        GPIO.setup(self.pin_in, GPIO.IN, pull_up_down = GPIO.PUD_DOWN)
        self.out_off()
        GPIO.add_event_detect(self.pin_in, GPIO.RISING, callback=self.recv_pulse_callback)


    def out_on(self):
        if self.out_inverse:
            GPIO.output(self.pin_out, 0)
        else:
            GPIO.output(self.pin_out, 1)

    def out_off(self):
        GPIO.setmode(GPIO.BOARD)
        if self.out_inverse:
            GPIO.output(self.pin_out, 1)
        else:
            GPIO.output(self.pin_out, 0)

    def recv_pulse_callback(self,ch):
        self.recv_pulses += 1

    def trig(self):
        self.out_on()
        sleep(self.pulse_width)
        self.out_off()
        self.trig_pulses += 1

    #### for use
    def reset_trig_pulses(self):
        self.trig_pulses = 0

    def reset_recv_pulses(self):
        self.recv_pulses = 0

    def set_max_miss_pulses(self, max_miss_pulses):
        self.max_miss_pulses = max_miss_pulses 

    def get_miss_pulses(self):
        return self.trig_pulses - self.recv_pulses

    def set_freq(self, freq= 5.0):
        if((freq > 0.0) and (freq < 30.0)):
            self.pulse_delay = 1.0 / float(freq)

    def get_freq(self):
        return 1.0 / self.pulse_delay

    def set_target_pulses(self, target_pulses):
        if(int(target_pulses) > 0):
            self.target_pulses = target_pulses

    def get_target_pulses(self):
        return  self.target_pulses

    def set_laser_on(self):
        self.laser_on = True
        self.time_start = time()

    def set_laser_off(self):
        self.laser_on = False

    def thread_func(self):
        while(config.system_run):
            #self.info()
            if(not self.laser_on ):
                sleep(0.1)
                continue
            if(self.recv_pulses >= self.target_pulses):
                self.set_laser_off()
                sleep(0.1)
                continue
            if(abs(self.trig_pulses - self.recv_pulses) >= self.max_miss_pulses):
                self.set_laser_off()
                sleep(0.1)
                continue

            self.trig()
            while(True):
                if( (time() - self.time_start) >= self.pulse_delay):
                    self.time_start += self.pulse_delay
                    break
                else:
                    sleep(0.001)

        ## system stop
        print "remove event detect %d" % self.pin_in
        GPIO.setmode(GPIO.BOARD)
        GPIO.remove_event_detect(self.pin_in)

    def run(self):
        self.thread = Thread(target=self.thread_func,args=())
        self.thread.start()
        
    def info(self):
        print "pin_in: %d \t pin_out : %d" % (self.pin_in, self.pin_out)
        print "target: %d \t trig: %d \t recv: %d" % (self.target_pulses, self.trig_pulses, self.recv_pulses)
        print "max_miss: %d \t miss: %d\n" % (self.max_miss_pulses, self.trig_pulses - self.recv_pulses)
        print "Laser : %s" % "ON" if self.laser_on else "OFF"
        print "freq : %f" % (1.0 / self.pulse_delay)




if __name__ == "__main__":
    print "test krf laser code"
    krf = krfLaser()
    krf.set_target_pulses(50)
    krf.set_freq(2)
    krf.set_laser_on()
    krf.set_max_miss_pulses(100)
    krf.run()

    for i in range(300):
        krf.info()
        sleep(1)
        if krf.laser_on == False:
            print "laser off..."
            config.system_run = False
            break

    config.system_run = False
    print "system stop"
