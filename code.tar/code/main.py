#!/usr/bin/env python

from gui import main_view


if __name__=="__main__":
    mgui = main_view()
    mgui.root.mainloop()
